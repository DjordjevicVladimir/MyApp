﻿using System;
using System.Collections.Generic;
using KolotreeWebApi;
using KolotreeWebApi.Models;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            UserService userService = new UserService();
            ProjectService projectService = new ProjectService();
            HoursRecordService userOnProjectService = new HoursRecordService();
            ReportService reports = new ReportService();

            User user = userService.FindUser(1);

            ReportPerUser reportPerUser = reports.GetReportPerUser(user);
            SumProjectsReport sumProjectsReport = reports.GetSumProjectsReport();
            Console.Read();
            
        }
    }
}
